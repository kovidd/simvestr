import React, { useState, useEffect, useContext } from "react";
import {
  Box,
  Grid,
  Paper,
  Typography,
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  LinearProgress,
} from "@material-ui/core";
import { LinkRouter } from "../ui";
import { HistoricChart } from "./HistoricChart";
import {
  PortfolioContext,
  getPortfolioDetails,
} from "../../services/portfolio";
import { PriceTypography, PriceTableCell } from "../ui";
import {
  changeArrow,
  formatCurrency,
  formatPerc,
  getQuoteChangePerc,
} from "../../helpers";

export const Dashboard = () => {
  const { portfolio, setPortfolio } = useContext(PortfolioContext);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    setIsLoading(true);
    getPortfolioDetails(setPortfolio).then(() => setIsLoading(false));
  }, [setPortfolio]);

  const netPortfolio = portfolio.balance + portfolio.totalValue;
  const previousDayPortfolio =
    portfolio.previousBalance + portfolio.previousInvestmentValue;
  const dayReturn = netPortfolio - previousDayPortfolio;
  const dayReturnPerc = dayReturn / previousDayPortfolio;
  const totalPortfolioReturn = portfolio.totalReturn;
  const totalPortfolioReturnPerc = totalPortfolioReturn / 100000;

  return (
    <Box mt="1rem" minHeight="300px">
      {isLoading ? (
        <LinearProgress />
      ) : (
        <Grid container spacing={2}>
          <Grid item xs={12} md={4}>
            <Typography variant="body2">Portfolio Position</Typography>
            <Paper variant="outlined">
              <Box minHeight="280px" p="1rem">
                <Typography variant="body2">Net Portfolio</Typography>
                <Typography variant="h4">
                  {formatCurrency(netPortfolio)}
                </Typography>
                <PriceTypography variant="body2" change={dayReturn}>{`${
                  dayReturn >= 0 ? "+" : ""
                }${formatCurrency(dayReturn)}  (${formatPerc(
                  Math.abs(dayReturnPerc)
                )}) Day ${changeArrow(dayReturn)}`}</PriceTypography>
                <PriceTypography
                  variant="body2"
                  change={totalPortfolioReturn}
                >{`${totalPortfolioReturn >= 0 ? "+" : ""}${formatCurrency(
                  totalPortfolioReturn
                )}  (${formatPerc(
                  Math.abs(totalPortfolioReturnPerc)
                )}) Total ${changeArrow(
                  totalPortfolioReturn
                )}`}</PriceTypography>
              </Box>
            </Paper>
          </Grid>
          <Grid item xs={12} md={8}>
            <Typography variant="body2">Historical Performance</Typography>
            <Paper variant="outlined">
              <Box minHeight="280px">
                <HistoricChart netPortfolio={netPortfolio} />
              </Box>
            </Paper>
          </Grid>
          <Grid item xs={12}>
            <Typography variant="body2">Portfolio Constituents</Typography>
            <Paper variant="outlined">
              <Box minHeight="15em" overflow="auto">
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell>Symbol</TableCell>
                      <TableCell align="right">Units</TableCell>
                      <TableCell align="right">Price</TableCell>
                      <TableCell align="right">Change</TableCell>
                      <TableCell align="right">Average Price</TableCell>
                      <TableCell align="right">Current Value</TableCell>
                      <TableCell align="right">Total Paid</TableCell>
                      <TableCell align="right">Total Return</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    <TableRow key="currency">
                      <TableCell colSpan={5}>CASH</TableCell>
                      <TableCell align="right">
                        {formatCurrency(portfolio.balance)}
                      </TableCell>
                      <TableCell colSpan={2}></TableCell>
                    </TableRow>
                    {portfolio.portfolio.map((stock) => {
                      const changePerc = getQuoteChangePerc(
                        stock.current,
                        stock.previous
                      );
                      const totalReturn = stock.return;
                      const totalReturnPerc = totalReturn / stock.buy.total;
                      return (
                        <TableRow key={stock.symbol}>
                          <TableCell>
                            <LinkRouter to={`stocks/${stock.symbol}`}>
                              {stock.symbol}
                            </LinkRouter>
                          </TableCell>
                          <TableCell align="right">{stock.quantity}</TableCell>
                          <TableCell align="right">
                            {formatCurrency(stock.current)}
                          </TableCell>
                          <PriceTableCell
                            align="right"
                            change={changePerc}
                          >{`${formatPerc(Math.abs(changePerc))} ${changeArrow(
                            changePerc
                          )}`}</PriceTableCell>
                          <TableCell align="right">
                            {formatCurrency(stock.buy.weighted_average)}
                          </TableCell>
                          <TableCell align="right">
                            {formatCurrency(stock.value)}
                          </TableCell>
                          <TableCell align="right">
                            {formatCurrency(stock.buy.total)}
                          </TableCell>
                          <PriceTableCell align="right" change={totalReturn}>
                            {`${formatCurrency(totalReturn)} (${formatPerc(
                              Math.abs(totalReturnPerc)
                            )}) ${changeArrow(totalReturn)}`}
                          </PriceTableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </Box>
            </Paper>
          </Grid>
        </Grid>
      )}
    </Box>
  );
};
